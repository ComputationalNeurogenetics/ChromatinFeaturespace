data_path <- "/Volumes/RuggedLaCie/Data/"
cores <- 6
macs2_path <- "/opt/homebrew/Caskroom/miniforge/base/envs/macs2/bin/macs2" # Point to macs2 conda env macs2