utils::globalVariables(c(
  "barcode", 
  "clus.param", 
  "h", 
  "heights.to.test", 
  "p", 
  "BSgenome.Mmusculus.UCSC.mm10" 
))