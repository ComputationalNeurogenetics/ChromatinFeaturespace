library(FeatureSpace)
library(Signac)
library(common)
library(BSgenome.Mmusculus.UCSC.mm10)
library(proxy)
library(Seurat)
library(dendextend)
library(fpc)
library(parallel)

# Each replicate of the same sample origin into the p and run for all

# Sample origin #1
p<-c("/Volumes/MyBookDuo/Workspace escape/Lucy/Cellranger_ARC/S14GFPHET_SC_E14_5/")
S14GFPHET <- ProcessReplicates(p,sample.names=c("_HET"),barcode.file="per_barcode_metrics.csv",is.cell.name="is_cell",buffer_length=512L)

# Sample origin #2
p<-c("/Volumes/MyBookDuo/Workspace escape/Lucy/Cellranger_ARC/S14GFPHOM_SC_E14_5/")
S14GFPHOM <- ProcessReplicates(p,sample.names=c("_HOM"),barcode.file="per_barcode_metrics.csv",is.cell.name="is_cell",buffer_length=512L)

# In the case of two or more sample origins
S14.merged <- merge(x = S14GFPHET$merged, y = c(S14GFPHOM$merged), add.cell.ids = c("_HET","_HOM"))

# Gene annotations from EnsDb
annotations <- readRDS("./metadata/Ensembel_Mmusculus79_annotation.Rds")

# Change to UCSC style
seqlevelsStyle(annotations) <- 'UCSC'
genome(annotations) <- "mm10"

# Add the gene information to the object
Signac::Annotation(S14.merged) <- annotations

# TODO: Write function for QC

# Calculate and plot nucleosome signal
S14.merged <- NucleosomeSignal(object = S14.merged)
S14.merged$nucleosome_group <- ifelse(S14.merged$nucleosome_signal > 4, 'NS > 4', 'NS < 4')
FragmentHistogram(object = S14.merged, group.by = 'nucleosome_group', region = 'chr1-1-10000000')

# TSS Enrichment
S14.merged <- TSSEnrichment(S14.merged, fast = FALSE)

# Plot QC data
S14.merged$pct_reads_in_peaks <- (S14.merged$atac_peak_region_fragments / S14.merged$atac_fragments) * 100
#S14.merged$blacklist_ratio <- S14.merged$blacklist_region_fragments / S14.merged$peak_region_fragments

VlnPlot(
  object = S14.merged,
  features = c('pct_reads_in_peaks', 'atac_peak_region_fragments',
               'TSS.enrichment', 'nucleosome_signal'),
  pt.size = 0.1,
  ncol = 5
)

# Filter based on QC
S14.merged.filt <- subset(
  x = S14.merged,
  subset = atac_peak_region_fragments > 2500 &
    atac_peak_region_fragments < 25000 &
    pct_reads_in_peaks > 20 &
    nucleosome_signal < 0.6 &
    TSS.enrichment > 4.5
)

S14.merged.filt <- FrequencyFilter(S14.merged.filt)

S14.merged.filt[["clade_peaks_count"]] <- S14.merged.filt[["clade_peaks"]]

# TODO: Write wrapper function for TFIDF etc..

DefaultAssay(S14.merged.filt) <- 'clade_peaks'
S14.merged.filt <- BinarizeCounts(S14.merged.filt, assay = "clade_peaks")
S14.merged.filt <- RunTFIDF(S14.merged.filt)
S14.merged.filt <- FindTopFeatures(S14.merged.filt, min.cutoff = 'q5')
S14.merged.filt <- RunSVD(object = S14.merged.filt)

DepthCor(S14.merged.filt)
hcd_02 <- RightSVD_dist(S14.merged.filt, drop.components = 1)
heights.to.test <- seq(4,10,by=1)

clade.stats_02 <- CladeStats(S14.merged.filt,hcd,heights=heights.to.test, cores=8)
PlotCladeStats(clade.stats = clade.stats_02)
PlotCladeTree(hcd=hcd_02, cut.height = 9)

cells_tree_cut_02 = cutree(hcd_02$hclust.cells, h=h)
lsi_cells_02 = dplyr::tibble(barcode = Cells(S14.merged.filt), cells_tree_cut = cells_tree_cut_02)

S14.merged.filt <- AddMetaData(S14.merged.filt, lsi_cells_02$cells_tree_cut, "clade")
clade.peaks_02_bed <- CallPeaks(S14.merged.filt, macs2.path = "/Users/kilpinen/miniforge3/envs/macs2/bin/macs2", effective.genome.size = 1.87e9, group.by = "clade", combine.peaks = TRUE, name = paste("Example_02_per_clade_peaks_merged", sep=""))

qsave(clade.peaks_02_bed,file="clade.peaks_02_bed.qs")

qsave(S14.merged.filt,"examples/Example_02_filt.qs", nthreads = 6)
