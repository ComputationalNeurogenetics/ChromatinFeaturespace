#' @title CreateChromAssay
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateChromAssay <- function(data.list, genome="mm10"){
  data.list <- lapply(data.list, function(p){
  p$chr.assay <- Signac::CreateChromatinAssay(counts = p$feature.matrix, fragments = list(p$fragmentObject), genome = GenomeInfoDb::Seqinfo(genome=genome), ranges = Signac::StringToGRanges(rownames(p$feature.matrix)))
  return(p)
})
  return(data.list)
}
