#' @title CreateFragmentObject
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateFragmentObject <- function(data.list, validate.fragments = FALSE){
data.list <- lapply(data.list, function(p){
  p$fragmentObject <- Signac::CreateFragmentObject(path = p$filterered.fragment.name, cells = p$true.cell.barcodes, validate.fragments = validate.fragments)
  return(p)
})
  return(data.list)
}
