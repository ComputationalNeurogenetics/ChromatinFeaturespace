#' @title CreateSeuratObj
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateSeuratObj <- function(data.list){
data.files <- lapply(data.list, function(p){
  tmp.metadata <- as.data.frame(dplyr::filter(p$barcode.metadata, barcode %in% p$true.cell.barcodes))
  rownames(tmp.metadata) <- tmp.metadata$barcode

  p$seurat.obj <- Seurat::CreateSeuratObject(
    counts =  p$chr.assay,
    assay = 'clade_peaks',
    project = 'ATAC',
    meta.data = tmp.metadata
  )

  return(p)
})
  return(data.files)
}
