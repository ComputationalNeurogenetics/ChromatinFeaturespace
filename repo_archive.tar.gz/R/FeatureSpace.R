#' @title CladeStats
#' @description
#' @param
#' @return
#' @example
#' @examples

CladeStats <- function(data.obj, rightSVD.cells, heights, cores){
  hclust.obj <- rightSVD.cells$hclust.cells
  cell.dist <- rightSVD.cells$cell.dist
  if (cores>1){
    cluster.stats.list <- mclapply(heights,function(h){
      cells_tree_cut = dendextend::cutree(hclust.obj, h=h)
      lsi_cells = dplyr::tibble(barcode = Cells(data.obj), cells_tree_cut = cells_tree_cut)
      tmp.stats <- fpc::cluster.stats(d=cell.dist, clustering=lsi_cells$cells_tree_cut)
      return(tmp.stats)
    },mc.cores=cores)
  } else if (cores==1){
    cluster.stats.list <- lapply(heights,function(h){
      cells_tree_cut = dendextend::cutree(hclust.obj, h=h)
      lsi_cells = dplyr::tibble(barcode = Cells(data.obj), cells_tree_cut = cells_tree_cut)
      tmp.stats <- fpc::cluster.stats(d=cell.dist, clustering=lsi_cells$cells_tree_cut)
      return(tmp.stats)
    })
  }
  return(cluster.stats.list)
}


#' @title FrequencyFilter
#' @description
#' @param
#' @return
#' @example
#' @examples

FrequencyFilter <- function(data.object, min.cells=0.025, max.cells=0.975, min.features=0.025, max.features=0.975){
  min.cells.thr <- round(length(unique(Cells(data.object)))*min.cells, digits = 0)
  max.cells.thr <- round(length(unique(Cells(data.object)))*max.cells, digits = 0)

  min.features.thr <- round(nrow(data.object)*min.features, digits = 0)
  max.features.thr <- round(nrow(data.object)*max.features, digits = 0)

  cell.per.feature <- rowSums(GetAssayData(data.object[["clade_peaks"]])>0)
  feature.per.cell <- colSums(GetAssayData(data.object[["clade_peaks"]])>0)

  feature.filter.index <- which(cell.per.feature >= min.cells.thr & cell.per.feature <= max.cells.thr)
  cell.filter.index <- which(feature.per.cell >= min.features.thr & feature.per.cell <= max.features.thr)

  features.to.keep <- rownames(data.object)[feature.filter.index]
  cells.to.keep <- Cells(data.object)[cell.filter.index]

  data.object <- subset(data.object, cells = cells.to.keep, features = features.to.keep)
  return(data.object)
}

#' @title CreateChromAssay
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateChromAssay <- function(data.list, genome="mm10"){
  data.list <- lapply(data.list, function(p){
    p$chr.assay <- Signac::CreateChromatinAssay(counts = p$feature.matrix, fragments = list(p$fragmentObject), genome = GenomeInfoDb::Seqinfo(genome=genome), ranges = Signac::StringToGRanges(rownames(p$feature.matrix)))
    return(p)
  })
  return(data.list)
}

#' @title CreateFeatureMatrix
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateFeatureMatrix <- function(data.list, binsize=5000, process_n=5000){
  data.list <- lapply(data.list, function(p){
    p$feature.matrix <- Signac::GenomeBinMatrix(fragments = list(p$fragmentObject), binsize = binsize, genome = p$genome.lengths, process_n = process_n)
    return(p)
  })
  return(data.list)
}

#' @title CreateFragmentObject
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateFragmentObject <- function(data.list, validate.fragments = FALSE){
  data.list <- lapply(data.list, function(p){
    p$fragmentObject <- Signac::CreateFragmentObject(path = p$filterered.fragment.name, cells = p$true.cell.barcodes, validate.fragments = validate.fragments)
    return(p)
  })
  return(data.list)
}

#' @title CreateSeuratObj
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateSeuratObj <- function(data.list){
  data.files <- lapply(data.list, function(p){
    tmp.metadata <- as.data.frame(dplyr::filter(p$barcode.metadata, barcode %in% p$true.cell.barcodes))
    rownames(tmp.metadata) <- tmp.metadata$barcode

    p$seurat.obj <- Seurat::CreateSeuratObject(
      counts =  p$chr.assay,
      assay = 'clade_peaks',
      project = 'ATAC',
      meta.data = tmp.metadata
    )

    return(p)
  })
  return(data.files)
}


#' @title FilterFragments
#' @description
#' @param
#' @return
#' @example
#' @examples

FilterFragments <- function(data.list, force=FALSE,buffer_length=256L){
  data.files <- lapply(data.list, function(p){
    p$filterered.fragment.name <- paste(dirname(p$fragment.file),"/",str_replace(basename(p$fragment.file),pattern = ".tsv.gz",replacement = ".filtered.tsv.gz"),sep="")
    if (!file.exists(p$filterered.fragment.name) | force){
      Signac::FilterCells(
        fragments = p$fragment.file,
        cells = p$true.cell.barcodes,
        outfile = p$filterered.fragment.name,
        buffer_length = buffer_length,
        verbose = TRUE
      )
    } else {
      print("Filtered fragments file exists, recreate with force=TRUE")
    }
    return(p)
  })
  return(data.files)
}


#' @title Find datafiles (barcode and fragment files)
#' @description
#' @param
#' @return
#' @example
#' @examples

FindDataFiles <- function(data.paths,sample.names, barcode.file="singlecell.csv"){

  data.files <- lapply(data.paths, function(p){
    barcode.file <- file.find(path=p, pattern = barcode.file)
    fragment.file <- file.find(path=p, pattern = "*fragments.tsv.gz")
    return(list(barcode.file=barcode.file, fragment.file=fragment.file, sample.name=sample.names))
  })

  names(data.files) <- names(sample.names)

  return(data.files)
}

#' @title MergeReplicates
#' @description
#' @param
#' @return
#' @example
#' @examples

MergeReplicates <- function(data.list){
  if (length(data.list)>1){
    data.list$merged <- merge(x = data.list[[1]]$seurat.obj, y = lapply(2:length(data.list),function(d){data.list[[d]]$seurat.obj}), add.cell.ids = c("_0","_1", "_2"))
  } else {
    data.list$merged <- data.list[[1]]$seurat.ob
  }
  return(data.list)
}

#' @title ProcessReplicates
#' @description
#' @param
#' @return
#' @example
#' @examples

ProcessReplicates <- function(data.paths,sample.names, barcode.file="singlecell.csv", is.cell.name="is__cell", force=FALSE, validate.fragments=FALSE, genome="mm10", genome.obj=BSgenome.Mmusculus.UCSC.mm10, used.chromosomes = c("chr1", "chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19"),binsize=5000, process_n=5000,buffer_length=256L){
  data.files <- FindDataFiles(p,sample.names =sample.names, barcode.file=barcode.file)
  data.files <- ReadBarcodeMetadata(data.files, is.cell.name = is.cell.name)
  data.files <- FilterFragments(data.files, force=force, buffer_length=buffer_length)
  data.files <- CreateFragmentObject(data.files, validate.fragments = validate.fragments)
  data.files <- SetUsedChromosomes(data.files, genome.obj=genome.obj, used.chromosomes = used.chromosomes)
  data.files <- CreateFeatureMatrix(data.files, binsize=binsize, process_n=process_n)
  data.files <- CreateChromAssay(data.files, genome=genome)
  data.files <- CreateSeuratObj(data.files)
  data.files <- MergeReplicates(data.files)
  return(data.files)
}

#' @title ReadBarcodeMetadata
#' @description
#' @param
#' @return
#' @example
#' @examples

ReadBarcodeMetadata <- function(data.list, is.cell.name="is__cell_barcode"){
  data.list <- lapply(data.list, function(p){
    p$barcode.metadata <- read_csv(file = p$barcode.file, show_col_types = FALSE)
    p$true.cell.barcodes <- dplyr::filter(p$barcode.metadata, !!rlang::sym(is.cell.name) == 1) %>% pull(barcode)
    return(p)
  })
  return(data.list)
}

#' @title RightSVD_dist
#' @description
#' @param
#' @return
#' @example
#' @examples

RightSVD_dist <- function(data.object, drop.components=1){
  SVD.d <- data.object@reductions$lsi@misc$d
  SVD.u <- data.object@reductions$lsi@misc$u
  num.dimensions <- ncol(data.object@reductions$lsi)
  d_diagtsne = matrix(0, nrow=num.dimensions, ncol=num.dimensions)
  diag(d_diagtsne) = SVD.d
  if (!any(is.na(drop.components))){
    d_diagtsne[drop.components,drop.components] = 0
  }
  SVDtsne_vd = t(d_diagtsne %*% t(SVD.u))
  cell.dist <- proxy::dist(SVDtsne_vd, method="cosine")
  hclust_cells <- hclust(cell.dist, method="ward.D2")
  return(list(hclust.cells=hclust_cells, cell.dist=cell.dist))
}

#' @title SetUsedChromosomes
#' @description
#' @param
#' @return
#' @example
#' @examples

SetUsedChromosomes <- function(data.list, genome.obj=BSgenome.Mmusculus.UCSC.mm10, used.chromosomes = c("chr1", "chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19")){
  data.files <- lapply(data.list, function(p){
    p$genome.lengths  <- GenomeInfoDb::seqlengths(genome.obj)[names(GenomeInfoDb::seqlengths(genome.obj)) %in% used.chromosomes]
    return(p)
  })
  return(data.files)
}

#' @title PlotCladeTree
#' @description
#' @param
#' @return
#' @example
#' @examples

PlotCladeTree <- function(hcd, cut.height){
  par(mai=c(2,.5,.25,.25),cex=.75)
  hcd.cut <- cut(as.dendrogram(hcd$hclust.cells), h = cut.height)
  hcd.upper<-hcd.cut$upper
  hcd.upper.clusters<-dendextend::cutree(hcd.upper,h=cut.height)
  hcd.upper<-dendextend::reindex_dend(hcd.upper)
  # Find out why this needs to be done, what is not reset in the object after cut but is reset after conversion back and worth
  hcd.upper<-as.dendrogram(as.hclust(hcd.upper))
  n.term.nodes <- sapply(hcd.cut$lower,dendextend::count_terminal_nodes)
  leaf.labels <- paste("Clade #",hcd.upper.clusters,": ",n.term.nodes," cells",sep="")
  hcd.upper<-dendextend::set_labels(hcd.upper,leaf.labels)
  #color_branches(hcd.upper,clusters=hcd.upper.clusters,col=color.vector(hcd.upper.clusters))
  hcd.upper %>% dendextend::set("branches_lwd",5) %>% dendextend::set("labels_cex",1.2) %>% plot(center=T)
  abline(h = h, lty = 2, col="red", lwd=2)
}

#' @title PlotCladeStats
#' @description
#' @param
#' @return
#' @example
#' @examples

PlotCladeStats <- function(clade.stats){
  avg.silhouette <- sapply(clade.stats, function(x){x$avg.silwidth})
  dunn2 <- sapply(clade.stats, function(x){x$dunn2})
  clusterint.stats <- tibble(clus.param=heights.to.test, dunn2=dunn2, avg.silhouette=avg.silhouette)
  ggplot(clusterint.stats, aes(x=clus.param, group=1)) + geom_line(aes(y=dunn2, color="Dunn2")) + theme_minimal() + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + scale_y_continuous("Dunn2", sec.axis = sec_axis(~ (. / 2.5), name = "Avg. Silhouette")) + geom_line(aes(y=avg.silhouette*2.5, color="Avg. Silhouette")) + xlab("Clade cutting height") + scale_x_continuous(breaks = seq(4, 10, by = 0.5))  + theme(legend.title=element_blank(), text = element_text(size=16))
}
