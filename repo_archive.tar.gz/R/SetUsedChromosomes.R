#' @title SetUsedChromosomes
#' @description
#' @param
#' @return
#' @example
#' @examples

SetUsedChromosomes <- function(data.list, genome.obj=BSgenome.Mmusculus.UCSC.mm10, used.chromosomes = c("chr1", "chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19")){
data.files <- lapply(data.list, function(p){
  p$genome.lengths  <- GenomeInfoDb::seqlengths(genome.obj)[names(GenomeInfoDb::seqlengths(genome.obj)) %in% used.chromosomes]
  return(p)
})
  return(data.files)
}
