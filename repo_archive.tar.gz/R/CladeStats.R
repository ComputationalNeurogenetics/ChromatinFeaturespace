#' @title CladeStats
#' @description
#' @param
#' @return
#' @example
#' @examples

CladeStats <- function(data.obj, rightSVD.cells, heights, cores){
  hclust.obj <- rightSVD.cells$hclust.cells
  cell.dist <- rightSVD.cells$cell.dist
  if (cores>1){
    cluster.stats.list <- mclapply(heights,function(h){
      cells_tree_cut = dendextend::cutree(hclust.obj, h=h)
      lsi_cells = dplyr::tibble(barcode = Cells(data.obj), cells_tree_cut = cells_tree_cut)
      tmp.stats <- fpc::cluster.stats(d=cell.dist, clustering=lsi_cells$cells_tree_cut)
      return(tmp.stats)
    },mc.cores=cores)
  } else if (cores==1){
    cluster.stats.list <- lapply(heights,function(h){
      cells_tree_cut = dendextend::cutree(hclust.obj, h=h)
      lsi_cells = dplyr::tibble(barcode = Cells(data.obj), cells_tree_cut = cells_tree_cut)
      tmp.stats <- fpc::cluster.stats(d=cell.dist, clustering=lsi_cells$cells_tree_cut)
      return(tmp.stats)
    })
  }
  return(cluster.stats.list)
}
