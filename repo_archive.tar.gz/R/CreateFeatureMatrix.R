#' @title CreateFeatureMatrix
#' @description
#' @param
#' @return
#' @example
#' @examples

CreateFeatureMatrix <- function(data.list, binsize=5000, process_n=5000){
  data.list <- lapply(data.list, function(p){
  p$feature.matrix <- Signac::GenomeBinMatrix(fragments = list(p$fragmentObject), binsize = binsize, genome = p$genome.lengths, process_n = process_n)
  return(p)
})
  return(data.list)
}
