#' @title MergeReplicates
#' @description
#' @param
#' @return
#' @example
#' @examples

MergeReplicates <- function(data.list){
if (length(data.list)>1){
  data.list$merged <- merge(x = data.list[[1]]$seurat.obj, y = lapply(2:length(data.list),function(d){data.list[[d]]$seurat.obj}), add.cell.ids = c("_0","_1", "_2"))
} else {
  data.list$merged <- data.list[[1]]$seurat.ob
}
  return(data.list)
}
