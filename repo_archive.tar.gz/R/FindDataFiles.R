#' @title Find datafiles (barcode and fragment files)
#' @description
#' @param
#' @return
#' @example
#' @examples

FindDataFiles <- function(data.paths,sample.names, barcode.file="singlecell.csv"){

data.files <- lapply(data.paths, function(p){
    barcode.file <- file.find(path=p, pattern = barcode.file)
    fragment.file <- file.find(path=p, pattern = "*fragments.tsv.gz")
    return(list(barcode.file=barcode.file, fragment.file=fragment.file, sample.name=sample.names))
  })

names(data.files) <- names(sample.names)

return(data.files)
}




