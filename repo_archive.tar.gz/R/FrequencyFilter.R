#' @title FrequencyFilter
#' @description
#' @param
#' @return
#' @example
#' @examples

FrequencyFilter <- function(data.object, min.cells=0.025, max.cells=0.975, min.features=0.025, max.features=0.975){
  min.cells.thr <- round(length(unique(Cells(data.object)))*min.cells, digits = 0)
  max.cells.thr <- round(length(unique(Cells(data.object)))*max.cells, digits = 0)

  min.features.thr <- round(nrow(data.object)*min.features, digits = 0)
  max.features.thr <- round(nrow(data.object)*max.features, digits = 0)

  cell.per.feature <- rowSums(GetAssayData(data.object[["clade_peaks"]])>0)
  feature.per.cell <- colSums(GetAssayData(data.object[["clade_peaks"]])>0)

  feature.filter.index <- which(cell.per.feature >= min.cells.thr & cell.per.feature <= max.cells.thr)
  cell.filter.index <- which(feature.per.cell >= min.features.thr & feature.per.cell <= max.features.thr)

  features.to.keep <- rownames(data.object)[feature.filter.index]
  cells.to.keep <- Cells(data.object)[cell.filter.index]

  data.object <- subset(data.object, cells = cells.to.keep, features = features.to.keep)
  return(data.object)
}
