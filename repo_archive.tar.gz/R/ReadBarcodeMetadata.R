#' @title ReadBarcodeMetadata
#' @description
#' @param
#' @return
#' @example
#' @examples

ReadBarcodeMetadata <- function(data.list, is.cell.name="is__cell_barcode"){
  data.list <- lapply(data.list, function(p){
  p$barcode.metadata <- read_csv(file = p$barcode.file, show_col_types = FALSE)
  p$true.cell.barcodes <- dplyr::filter(p$barcode.metadata, !!rlang::sym(is.cell.name) == 1) %>% pull(barcode)
  return(p)
})
  return(data.list)
}
