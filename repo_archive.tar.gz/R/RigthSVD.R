#' @title RightSVD
#' @description
#' @param
#' @return
#' @example
#' @examples

RightSVD <- function(data.object, drop.components=1){
  SVD.d <- data.object@reductions$lsi@misc$d
  SVD.u <- data.object@reductions$lsi@misc$u
  num.dimensions <- ncol(data.object@reductions$lsi)
  d_diagtsne = matrix(0, nrow=num.dimensions, ncol=num.dimensions)
  diag(d_diagtsne) = SVD.d
  if (!any(is.na(drop.components))){
    d_diagtsne[drop.components,drop.components] = 0
  }
  SVDtsne_vd = t(d_diagtsne %*% t(SVD.u))
  cell.dist <- proxy::dist(SVDtsne_vd, method="cosine")
  hclust_cells <- hclust(cell.dist, method="ward.D2")
  return(list(hclust.cells=hclust_cells, cell.dist=cell.dist))
}
