#' @title ProcessReplicates
#' @description
#' @param
#' @return
#' @example
#' @examples

ProcessReplicates <- function(data.paths,sample.names, barcode.file="singlecell.csv", is.cell.name="is__cell", force=FALSE, validate.fragments=FALSE, genome="mm10", genome.obj=BSgenome.Mmusculus.UCSC.mm10, used.chromosomes = c("chr1", "chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19"),binsize=5000, process_n=5000,buffer_length=256L){
  data.files <- FindDataFiles(p,sample.names =sample.names, barcode.file=barcode.file)
  data.files <- ReadBarcodeMetadata(data.files, is.cell.name = is.cell.name)
  data.files <- FilterFragments(data.files, force=force, buffer_length=buffer_length)
  data.files <- CreateFragmentObject(data.files, validate.fragments = validate.fragments)
  data.files <- SetUsedChromosomes(data.files, genome.obj=genome.obj, used.chromosomes = used.chromosomes)
  data.files <- CreateFeatureMatrix(data.files, binsize=binsize, process_n=process_n)
  data.files <- CreateChromAssay(data.files, genome=genome)
  data.files <- CreateSeuratObj(data.files)
  data.files <- MergeReplicates(data.files)
return(data.files)
}

