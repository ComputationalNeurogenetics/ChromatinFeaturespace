#' @title FilterFragments
#' @description
#' @param
#' @return
#' @example
#' @examples

FilterFragments <- function(data.list, force=FALSE,buffer_length=256L){
data.files <- lapply(data.list, function(p){
  p$filterered.fragment.name <- paste(dirname(p$fragment.file),"/",str_replace(basename(p$fragment.file),pattern = ".tsv.gz",replacement = ".filtered.tsv.gz"),sep="")
  if (!file.exists(p$filterered.fragment.name) | force){
    Signac::FilterCells(
      fragments = p$fragment.file,
      cells = p$true.cell.barcodes,
      outfile = p$filterered.fragment.name,
      buffer_length = buffer_length,
      verbose = TRUE
    )
  } else {
    print("Filtered fragments file exists, recreate with force=TRUE")
  }
  return(p)
})
  return(data.files)
}
